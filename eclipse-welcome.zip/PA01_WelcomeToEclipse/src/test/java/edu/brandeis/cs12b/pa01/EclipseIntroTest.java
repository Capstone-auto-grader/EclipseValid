package edu.brandeis.cs12b.pa01;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import edu.brandeis.cs12b.pa01.EclipseIntroProblems;

public class EclipseIntroTest {	
	@Test
	public void countRepeatsTest() {
		assertEquals(0, EclipseIntroProblems.countRepeats(new int[] {1, 2, 3}));
		assertEquals(1, EclipseIntroProblems.countRepeats(new int[] {1, 3, 2, 2}));
		assertEquals(2, EclipseIntroProblems.countRepeats(new int[] {1, 4, 2, 6, 4, 2}));
	}
	
	@Test
	public void sum3Test() {
		assertTrue(EclipseIntroProblems.sum3(new int[] {5, 2, 4, -7}));
		assertFalse(EclipseIntroProblems.sum3(new int[] {5, 2, 4, 7}));
	}
	
	@Test
	public void isBalancedParensTest() {
		assertTrue(EclipseIntroProblems.isBalancedParens("()(())"));
		assertFalse(EclipseIntroProblems.isBalancedParens("(()"));
	}
	
	@Test
	public void isBalancedBracketsTest() {
		assertTrue(EclipseIntroProblems.isBalancedBrackets("(<>)"));
		assertTrue(EclipseIntroProblems.isBalancedBrackets("{}[]<>()"));
		assertFalse(EclipseIntroProblems.isBalancedBrackets("<()"));
	}
}
