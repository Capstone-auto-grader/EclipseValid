package edu.brandeis.cs12b.pa01;

public class EclipseIntroProblems {
	/**
	 * Returns the number of items that have duplicates in an array. For example,
	 * in the array {3, 1, 5, 5, 3}, countRepeats should return 2, because there are
	 * two numbers that are repeated -- three and five. 
	 * 
	 * @param items - an array of integers
	 * @return the number of integers in items array that are repeated more than once.
	 */
	public static int countRepeats(int[] items) {
		// TODO implement me
		return -1;
	}
	
	
	/**
	 * Return true if there are three integers in the items array that sum up to
	 * zero. Return false otherwise.
	 * 
	 * Examples: 
	 * {5, 4, 2, -7} -> TRUE, because (5 + 2 + -7 = 0) 
	 * {3, 4, 1, 52} -> FALSE, because there are no 3 integers in the array that sum up to 0.
	 * 
	 * @param items - an array of integers
	 * @return true - if there exist three integers in items array that add up to zero, 
	 *         otherwise, return false.
	 */
	public static boolean sum3(int[] items) {
		// TODO implement me!
		return false;

	}
	
	
	/**
	 * Returns true if a string of parenthesis is balanced.
	 * 
	 * Examples: "()"  -> TRUE (balanced)
	 *           "(()" -> FALSE (unmatched "(" )
	 *           
   	 * A string with any character beside '(' or ')' is invalid, and therefore not balanced.
	 *           
	 * @param str - an input string
	 * @return true - if str is a balanced string, 
	 *         otherwise, return false.
	 */
	public static boolean isBalancedParens(String str) {
		// TODO implement me!
		return false;
	}


	/**
	 * Similar to isBalancedParens, but this time we consider 4 types of brackets:
	 * ( ) , { } , [ ] and < >.
	 * 
	 * A string with any character beside the brackets is invalid, and therefore not balanced.
	 * 
	 * @param str - an input string
	 * @return true - if str is a balanced string, 
	 *         otherwise, return false.
	 */
	public static boolean isBalancedBrackets(String str) {
		// TODO implement me!
		return false;
	}
}

